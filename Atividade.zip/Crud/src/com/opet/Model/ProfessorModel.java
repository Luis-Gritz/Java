package com.opet.Model;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

@Named("professor")
@RequestScoped
public class ProfessorModel {
	
	private int id = -1;
	private String nome;
	private String matricula;
	private String disciplina1;
	private String disciplina2;
	private String disciplina3;

	public ProfessorModel(int id,String nome, String matricula, String disciplina1,String disciplina2,String disciplina3) {
		this.id = id;
		this.matricula = matricula;
		this.nome = nome;
		this.disciplina1 = disciplina1;
		this.disciplina2 = disciplina2;
		this.disciplina3 = disciplina3;
		
	}
	
	public ProfessorModel() {
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}
	
	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDisciplina1() {
		return disciplina1;
	}

	public void setDisciplina1(String disciplina1) {
		this.disciplina1 = disciplina1;
	}

	public String getDisciplina2() {
		return disciplina2;
	}

	public void setDisciplina2(String disciplina2) {
		this.disciplina2 = disciplina2;
	}

	public String getDisciplina3() {
		return disciplina3;
	}

	public void setDisciplina3(String disciplina3) {
		this.disciplina3 = disciplina3;
	}
	
	


}
