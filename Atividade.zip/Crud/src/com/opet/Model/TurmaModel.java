package com.opet.Model;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

@Named("turma")
@RequestScoped
public class TurmaModel {
	
	private int id  = -1;
	private String nome;
	
	public TurmaModel(int id, String nome){
		this.id = id;
		this.nome = nome;
		
	}
	
	public TurmaModel() {
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	

}
