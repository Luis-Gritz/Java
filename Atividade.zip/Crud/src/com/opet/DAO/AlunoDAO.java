package com.opet.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import com.opet.Model.AlunoModel;


public class AlunoDAO {
	
	private final String SALVAR = "insert into aluno(id, nome, matricula, idade) values(seqAluno.nextval, ?, ?, ?)";
	private final String LISTAR = "select id, nome, matricula, idade from aluno";
	private final String SELECIONAR = "id, nome, matricula, idade where id=?";
	private final String EDITAR = "update aluno set nome = ?, matricula = ?, idade = ? where id = ?";
	private final String DELETAR = "delete from aluno where id = ?";

	public ArrayList<AlunoModel> listarAluno() {
		ArrayList<AlunoModel> listaAluno = new ArrayList<AlunoModel>();
		Connection conn = Conexao.conectar();
		ResultSet rs = null;
		PreparedStatement stmt = null;
		try {
			stmt = conn.prepareStatement(LISTAR);
			rs = stmt.executeQuery();

			while (rs.next()) {
				listaAluno.add(new AlunoModel(rs.getInt("id"),
						rs.getString("nome"),
						rs.getString("matricula"),
						rs.getInt("idade")));
			}
		} catch (Exception e) {
			System.out.println("N�o foi poss�vel listar os dados");

		} finally {
			try {
				rs.close();
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println("A conex�o com o banco n�o conseguiu ser encerrada");
			}

		}
		return listaAluno;
	}
	
	public HashMap<Integer, AlunoModel> mapearAluno() {
		HashMap<Integer, AlunoModel> listaAluno = new HashMap<Integer, AlunoModel>();
		Connection conn = Conexao.conectar();
		ResultSet rs = null;
		PreparedStatement stmt = null;
		try {
			stmt = conn.prepareStatement(LISTAR);
			rs = stmt.executeQuery();

			while (rs.next()) {
				listaAluno.put(rs.getInt("id"),
						new AlunoModel(rs.getInt("id"),
								rs.getString("nome"),
								rs.getString("matricula"),
								rs.getInt("idade")));
			}
		} catch (Exception e) {
			System.out.println("N�o foi poss�vel listar os dados");
		} finally {
			try {
				rs.close();
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println("A conex�o com o banco n�o conseguiu ser encerrada");
			}

		}
		return listaAluno;
	}
	
	public AlunoModel selecionarAluno(int id) {
		Connection conn = Conexao.conectar();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.prepareStatement(SELECIONAR);
			stmt.setInt(1, id);
			rs = stmt.executeQuery();
			if (rs.next()) {
				return new AlunoModel(rs.getInt("id"),
						rs.getString("nome"),
						rs.getString("matricula"),
						rs.getInt("idade"));
			} else {
				return null;
			}
		} catch (Exception e) {
			System.out.println("N�o foi poss�vel selecionar o dado");
			return null;
		} finally {
			try {
				rs.close();
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println("N�o foi poss�vel encerrar conex�o com o banco");
			}
		}
	}

	public boolean existeAluno(int id) {
		Connection conn = Conexao.conectar();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.prepareStatement(SELECIONAR);
			stmt.setInt(1, id);
			rs = stmt.executeQuery();
			return rs.next();
		} catch (Exception e) {
			System.out.println("N�o foi poss�vel selecionar o dado");
			return false;
		} finally {
			try {
				rs.close();
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println("N�o foi poss�vel encerrar conex�o");
			}
		}
	}

	public boolean cadastrarAluno(AlunoModel aluno) {
		Connection conn = Conexao.conectar();
		PreparedStatement stmt = null;

		try {
			conn.setAutoCommit(false);
			stmt = conn.prepareStatement(SALVAR);
			stmt.setString(1, aluno.getNome());
			stmt.setString(2, aluno.getMatricula());
			stmt.setInt(3, aluno.getIdade());
			
			int rowAffected = stmt.executeUpdate();

			if (rowAffected != 1) {
				System.out.println("Algo deu errado");
				conn.rollback();
				return false;
			} else {
				conn.commit();
				return true;
			}
		} catch (Exception e) {
			System.out.println("N�o foi poss�vel fazer o cadastro");
			e.printStackTrace();
			return false;
		} finally {
			try {
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println("N�o encerrou conex�o");
			}
		}
	}

	public boolean alterarAluno(AlunoModel aluno) {
		Connection conn = Conexao.conectar();
		PreparedStatement stmt = null;

		try {
			conn.setAutoCommit(false);

			stmt = conn.prepareStatement(EDITAR);
			stmt.setString(1, aluno.getNome());
			stmt.setString(2, aluno.getMatricula());
			stmt.setInt(3, aluno.getIdade());
			stmt.setInt(4, aluno.getId());
			int rowAffected = stmt.executeUpdate();

			if (rowAffected != 1) {
				conn.rollback();
				return false;
			} else {
				conn.commit();
				return true;
			}
		} catch (Exception e) {
			System.out.println("N�o foi poss�vel alterar os dados");
			e.printStackTrace();
			return false;
		} finally {
			try {
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println("N�o foi poss�vel encerrar a conex�o");
			}
		}
	}
	
	public boolean deletarAluno(int id) {
		Connection conn = Conexao.conectar();
		PreparedStatement stmt = null;
		try {
			stmt = conn.prepareStatement(DELETAR);
			stmt.setInt(1, id);
			stmt.execute();
			return true;
		} catch (Exception e) {
			System.out.println("N�o foi poss�vel deletar");
			return false;
		} finally {
			try {
				stmt.close();
				conn.close();
			} catch (Exception e) {
				System.out.println("N�o foi poss�vel encerrar a conex�o");
			}
		}

	}

}
