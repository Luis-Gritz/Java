package com.opet.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import com.opet.Model.ProfessorModel;

public class ProfessorDAO {

	private final String SALVAR = "insert into professor(id, nome, matricula, disciplina1, disciplina2, disciplina3) values(seqProfessor.nextval, ?, ?, ?, ?, ?)";
	private final String LISTAR = "select id, nome, matricula, disciplina1,disciplina2, disciplina3 from professor";
	private final String SELECIONAR = "id, nome, matricula, disciplina1, disciplina2, disciplina3 where id=?";
	private final String EDITAR = "update professor set nome = ?, matricula = ?, disciplina1 = ?, disciplina2 = ?, disciplina3 = ? where id = ?";
	private final String DELETAR = "delete from professor where id = ?";

	public ArrayList<ProfessorModel> listarProfessor() {
		ArrayList<ProfessorModel> listaProfessor = new ArrayList<ProfessorModel>();
		Connection conn = Conexao.conectar();
		ResultSet rs = null;
		PreparedStatement stmt = null;
		try {
			stmt = conn.prepareStatement(LISTAR);
			rs = stmt.executeQuery();

			while (rs.next()) {
				listaProfessor.add(new ProfessorModel(rs.getInt("id"),
						rs.getString("nome"),
						rs.getString("matricula"),
						rs.getString("disciplina1"),
						rs.getString("disciplina2"),
						rs.getString("disciplina3")));
			}
		} catch (Exception e) {
			System.out.println("N�o foi poss�vel listar os dados");

		} finally {
			try {
				rs.close();
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println("A conex�o com o banco n�o conseguiu ser encerrada");
			}

		}
		return listaProfessor;
	}
	
	public HashMap<Integer, ProfessorModel> mapearProfessor() {
		HashMap<Integer, ProfessorModel> listaProfessor = new HashMap<Integer, ProfessorModel>();
		Connection conn = Conexao.conectar();
		ResultSet rs = null;
		PreparedStatement stmt = null;
		try {
			stmt = conn.prepareStatement(LISTAR);
			rs = stmt.executeQuery();

			while (rs.next()) {
				listaProfessor.put(rs.getInt("id"),
						new ProfessorModel(rs.getInt("id"),
								rs.getString("nome"),
								rs.getString("matricula"),
								rs.getString("disciplina1"),
								rs.getString("disciplina2"),
								rs.getString("disciplina3")));
			}
		} catch (Exception e) {
			System.out.println("N�o foi poss�vel listar os dados");
		} finally {
			try {
				rs.close();
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println("A conex�o com o banco n�o conseguiu ser encerrada");
			}

		}
		return listaProfessor;
	}
	
	public ProfessorModel selecionarProfessor(int id) {
		Connection conn = Conexao.conectar();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.prepareStatement(SELECIONAR);
			stmt.setInt(1, id);
			rs = stmt.executeQuery();
			if (rs.next()) {
				return new ProfessorModel(rs.getInt("id"),
						rs.getString("nome"),
						rs.getString("matricula"),
						rs.getString("disciplina1"),
						rs.getString("disciplina2"),
						rs.getString("disciplina3"));
			} else {
				return null;
			}
		} catch (Exception e) {
			System.out.println("N�o foi poss�vel selecionar o dado");
			return null;
		} finally {
			try {
				rs.close();
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println("N�o foi poss�vel encerrar conex�o com o banco");
			}
		}
	}

	public boolean existeProfessor(int id) {
		Connection conn = Conexao.conectar();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.prepareStatement(SELECIONAR);
			stmt.setInt(1, id);
			rs = stmt.executeQuery();
			return rs.next();
		} catch (Exception e) {
			System.out.println("N�o foi poss�vel selecionar o dado");
			return false;
		} finally {
			try {
				rs.close();
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println("N�o foi poss�vel encerrar conex�o");
			}
		}
	}

	public boolean cadastrarProfessor(ProfessorModel professor) {
		Connection conn = Conexao.conectar();
		PreparedStatement stmt = null;

		try {
			conn.setAutoCommit(false);
			stmt = conn.prepareStatement(SALVAR);
			stmt.setString(1, professor.getNome());
			stmt.setString(2, professor.getMatricula());
			stmt.setString(3, professor.getDisciplina1());
			stmt.setString(4, professor.getDisciplina2());
			stmt.setString(5, professor.getDisciplina3());

			
			int rowAffected = stmt.executeUpdate();

			if (rowAffected != 1) {
				System.out.println("Algo deu errado");
				conn.rollback();
				return false;
			} else {
				conn.commit();
				return true;
			}
		} catch (Exception e) {
			System.out.println("N�o foi poss�vel fazer o cadastro");
			e.printStackTrace();
			return false;
		} finally {
			try {
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println("N�o encerrou conex�o");
			}
		}
	}

	public boolean alterarProfessor(ProfessorModel professor) {
		Connection conn = Conexao.conectar();
		PreparedStatement stmt = null;

		try {
			conn.setAutoCommit(false);

			stmt = conn.prepareStatement(EDITAR);
			stmt.setString(1, professor.getNome());
			stmt.setString(2, professor.getMatricula());
			stmt.setString(3, professor.getDisciplina1());
			stmt.setString(4, professor.getDisciplina2());
			stmt.setString(5, professor.getDisciplina3());
			stmt.setInt(6, professor.getId());
			int rowAffected = stmt.executeUpdate();

			if (rowAffected != 1) {
				conn.rollback();
				return false;
			} else {
				conn.commit();
				return true;
			}
		} catch (Exception e) {
			System.out.println("N�o foi poss�vel alterar os dados");
			e.printStackTrace();
			return false;
		} finally {
			try {
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println("N�o foi poss�vel encerrar a conex�o");
			}
		}
	}
	
	public boolean deletarProfessor(int id) {
		Connection conn = Conexao.conectar();
		PreparedStatement stmt = null;
		try {
			stmt = conn.prepareStatement(DELETAR);
			stmt.setInt(1, id);
			stmt.execute();
			return true;
		} catch (Exception e) {
			System.out.println("N�o foi poss�vel deletar");
			return false;
		} finally {
			try {
				stmt.close();
				conn.close();
			} catch (Exception e) {
				System.out.println("N�o foi poss�vel encerrar a conex�o");
			}
		}

	}

}
