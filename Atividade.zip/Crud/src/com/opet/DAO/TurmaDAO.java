package com.opet.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import com.opet.Model.TurmaModel;

public class TurmaDAO {


	private final String SALVAR = "insert into turma(id, nome) values(seqTurma.nextval, ?)";
	private final String LISTAR = "select id, nome from turma";
	private final String SELECIONAR = "id, nome where id=?";
	private final String EDITAR = "update turma set nome = ? where id = ?";
	private final String DELETAR = "delete from turma where id = ?";

	public ArrayList<TurmaModel> listarTurma() {
		ArrayList<TurmaModel> listaTurma = new ArrayList<TurmaModel>();
		Connection conn = Conexao.conectar();
		ResultSet rs = null;
		PreparedStatement stmt = null;
		try {
			stmt = conn.prepareStatement(LISTAR);
			rs = stmt.executeQuery();

			while (rs.next()) {
				listaTurma.add(new TurmaModel(rs.getInt("id"),
						rs.getString("nome")));
			}
		} catch (Exception e) {
			System.out.println("N�o foi poss�vel listar os dados");

		} finally {
			try {
				rs.close();
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println("A conex�o com o banco n�o conseguiu ser encerrada");
			}

		}
		return listaTurma;
	}
	
	public HashMap<Integer, TurmaModel> mapearTurma() {
		HashMap<Integer, TurmaModel> listaAluno = new HashMap<Integer, TurmaModel>();
		Connection conn = Conexao.conectar();
		ResultSet rs = null;
		PreparedStatement stmt = null;
		try {
			stmt = conn.prepareStatement(LISTAR);
			rs = stmt.executeQuery();

			while (rs.next()) {
				listaAluno.put(rs.getInt("id"),
						new TurmaModel(rs.getInt("id"),
								rs.getString("nome")));
			}
		} catch (Exception e) {
			System.out.println("N�o foi poss�vel listar os dados");
		} finally {
			try {
				rs.close();
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println("A conex�o com o banco n�o conseguiu ser encerrada");
			}

		}
		return listaAluno;
	}
	
	public TurmaModel selecionarTurma(int id) {
		Connection conn = Conexao.conectar();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.prepareStatement(SELECIONAR);
			stmt.setInt(1, id);
			rs = stmt.executeQuery();
			if (rs.next()) {
				return new TurmaModel(rs.getInt("id"),
						rs.getString("nome"));
			} else {
				return null;
			}
		} catch (Exception e) {
			System.out.println("N�o foi poss�vel selecionar o dado");
			return null;
		} finally {
			try {
				rs.close();
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println("N�o foi poss�vel encerrar conex�o com o banco");
			}
		}
	}

	public boolean existeTurma(int id) {
		Connection conn = Conexao.conectar();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.prepareStatement(SELECIONAR);
			stmt.setInt(1, id);
			rs = stmt.executeQuery();
			return rs.next();
		} catch (Exception e) {
			System.out.println("N�o foi poss�vel selecionar o dado");
			return false;
		} finally {
			try {
				rs.close();
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println("N�o foi poss�vel encerrar conex�o");
			}
		}
	}

	public boolean cadastrarTurma(TurmaModel turma) {
		Connection conn = Conexao.conectar();
		PreparedStatement stmt = null;

		try {
			conn.setAutoCommit(false);
			stmt = conn.prepareStatement(SALVAR);
			stmt.setString(1, turma.getNome());
			
			int rowAffected = stmt.executeUpdate();

			if (rowAffected != 1) {
				System.out.println("Algo deu errado");
				conn.rollback();
				return false;
			} else {
				conn.commit();
				return true;
			}
		} catch (Exception e) {
			System.out.println("N�o foi poss�vel fazer o cadastro");
			e.printStackTrace();
			return false;
		} finally {
			try {
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println("N�o encerrou conex�o");
			}
		}
	}

	public boolean alterarTurma(TurmaModel turma) {
		Connection conn = Conexao.conectar();
		PreparedStatement stmt = null;

		try {
			conn.setAutoCommit(false);

			stmt = conn.prepareStatement(EDITAR);
			stmt.setString(1, turma.getNome());
			stmt.setInt(2, turma.getId());
			int rowAffected = stmt.executeUpdate();

			if (rowAffected != 1) {
				conn.rollback();
				return false;
			} else {
				conn.commit();
				return true;
			}
		} catch (Exception e) {
			System.out.println("N�o foi poss�vel alterar os dados");
			e.printStackTrace();
			return false;
		} finally {
			try {
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println("N�o foi poss�vel encerrar a conex�o");
			}
		}
	}
	
	public boolean deletarTurma(int id) {
		Connection conn = Conexao.conectar();
		PreparedStatement stmt = null;
		try {
			stmt = conn.prepareStatement(DELETAR);
			stmt.setInt(1, id);
			stmt.execute();
			return true;
		} catch (Exception e) {
			System.out.println("N�o foi poss�vel deletar");
			return false;
		} finally {
			try {
				stmt.close();
				conn.close();
			} catch (Exception e) {
				System.out.println("N�o foi poss�vel encerrar a conex�o");
			}
		}

	}
}
