package com.opet.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {
    public static Connection conectar() {
        Connection conn = null;
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            conn = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:xe", "system", "system");
            return conn;
        }catch(SQLException | ClassNotFoundException e){
            System.out.println("N�o foi poss�vel conectar no banco");
        }
        return conn;
    }
}
