package com.opet.Controller;

import java.io.Serializable;
import java.util.ArrayList;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opet.DAO.AlunoDAO;
import com.opet.Model.AlunoModel;

@Named("alunoBean")
@SessionScoped
public class AlunoBean implements Serializable {

	private static final long serialVersionUID = 6623271179313349482L;
	private AlunoDAO alunoDAO;
	
	@Inject
	private AlunoModel aluno;

	@PostConstruct
	public void init() {
		this.alunoDAO = new AlunoDAO();
		this.aluno = new AlunoModel();
	}

	public ArrayList<AlunoModel> getAlunos() {
		return alunoDAO.listarAluno();
	}

	public String salvarAluno() {
		if (this.aluno.getId() == -1) {
			this.alunoDAO.cadastrarAluno(this.aluno);
		} else {
			this.alunoDAO.alterarAluno(this.aluno);
		}
		this.aluno = new AlunoModel();
		return "respostaAluno";
	}

	public String editarAluno(AlunoModel a) {
		aluno.setId(a.getId());
		aluno.setNome(a.getNome());
		aluno.setMatricula(a.getMatricula());
		aluno.setIdade(a.getIdade());
		return "indexAluno";
	}

	public String removerAluno(AlunoModel a) {
		this.alunoDAO.deletarAluno(a.getId());
		return "respostaAluno";
	}

	public AlunoModel getAluno() {
		return aluno;
	}

	public void setAluno(AlunoModel aluno) {
		this.aluno = aluno;
	}

}
