package com.opet.Controller;

import java.io.Serializable;
import java.util.ArrayList;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;
import com.opet.DAO.TurmaDAO;
import com.opet.Model.TurmaModel;

@Named("turmaBean")
@SessionScoped
public class TurmaBean implements Serializable {

private static final long serialVersionUID = 6623271179313349482L;

private TurmaDAO turmaDAO;
	
	@Inject
	private TurmaModel turma;

	@PostConstruct
	public void init() {
		this.turmaDAO = new TurmaDAO();
		this.turma = new TurmaModel();
	}

	public ArrayList<TurmaModel> getTurmas() {
		return turmaDAO.listarTurma();
	}

	public String salvarTurma() {
		if (this.turma.getId() == -1) {
			this.turmaDAO.cadastrarTurma(this.turma);
		} else {
			this.turmaDAO.alterarTurma(this.turma);
		}
		this.turma = new TurmaModel();
		return "respostaTurma";
	}

	public String editarTurma(TurmaModel t) {
		turma.setId(t.getId());
		turma.setNome(t.getNome());
		return "indexTurma";
	}

	public String removerTurma(TurmaModel t) {
		this.turmaDAO.deletarTurma(t.getId());
		return "respostaTurma";
	}

	public TurmaModel getTurma() {
		return turma;
	}

	public void setTurma(TurmaModel turma) {
		this.turma = turma;
	}

}
