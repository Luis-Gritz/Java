package com.opet.Controller;

import java.io.Serializable;
import java.util.ArrayList;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opet.DAO.ProfessorDAO;
import com.opet.Model.ProfessorModel;

@Named("professorBean")
@SessionScoped
public class ProfessorBean implements Serializable {
	private static final long serialVersionUID = 6623271179313349482L;
	private ProfessorDAO professorDAO;
	
	@Inject
	private ProfessorModel professor;

	@PostConstruct
	public void init() {
		this.professorDAO = new ProfessorDAO();
		this.professor = new ProfessorModel();
	}

	public ArrayList<ProfessorModel> getProfessores() {
		return professorDAO.listarProfessor();
	}

	public String salvarProfessor() {
		if (this.professor.getId() == -1) {
			this.professorDAO.cadastrarProfessor(this.professor);
		} else {
			this.professorDAO.alterarProfessor(this.professor);
		}
		this.professor = new ProfessorModel();
		return "respostaProfessor";
	}

	public String editarProfessor(ProfessorModel p) {
		professor.setId(p.getId());
		professor.setNome(p.getNome());
		professor.setMatricula(p.getMatricula());
		professor.setDisciplina1(p.getDisciplina1());
		professor.setDisciplina2(p.getDisciplina2());
		professor.setDisciplina3(p.getDisciplina3());

		return "indexProfessor";
	}

	public String removerProfessor(ProfessorModel a) {
		this.professorDAO.deletarProfessor(a.getId());
		return "respostaProfessor";
	}

	public ProfessorModel getProfessor() {
		return professor;
	}

	public void setProfessor(ProfessorModel professor) {
		this.professor = professor;
	}

}
