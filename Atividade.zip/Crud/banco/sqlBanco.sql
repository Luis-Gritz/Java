create sequence seqProfessor;
create sequence seqAluno;
create sequence seqTurma;
create sequence seqDiciplina;

create sequence seqAlunoTurma;
create sequence seqTurmaProfessor;
create sequence seqProfessorDiciplina;

create table professor(
id number(12),
nome varchar2(50),
matricula varchar2(50),
disciplina1 varchar2(50),
disciplina2 varchar2(50),
disciplina3 varchar2(50));
constraint professor_pk primary key(id)

create table aluno(
id number(12),
nome varchar2(50),
matricula varchar2(50),
idade number(3));

create table turma(
id number(12),
nome varchar2(50));

create table disciplina(
id number(12),
nome varchar2(50),
constraint disciplina_pk primary key(id));

create table relacaoProfessorTurma(
id number(12),
idTabelaProfessor number(12),
idTabelaTurma number(12),
constraint relacaoProfessorTurma_pk primary key(id),
CONSTRAINT tabelaProfessor_pk foreign key(idTabelaProfessor) references professor(id),
CONSTRAINT tabelaTurma_pk foreign key(idTabelaTurma) references turma(id)
);

create table relacaoAlunoTurma(
id number(12),
idTabelaAluno number(12),
idTabelaTurma number(12),
constraint relacaoAlunoTurma_pk primary key(id),
CONSTRAINT tabelaAluno_pk foreign key(idTabelaAluno) references aluno(id),
CONSTRAINT tabelaTurma_pk foreign key(idTabelaTurma) references turma(id));

create table relacaoProfessorDisciplina(
id number(12),
idTabelaProfessor number(12),
idTabelaDisciplina number(12),
constraint relacaoProfessorDisciplina_pk primary key(id),
CONSTRAINT idTabelaProfessor_pk foreign key(idTabelaProfessor) references professor(id),
CONSTRAINT idTabelaDisciplina_pk foreign key(idTabelaDisciplina) references disciplina(id));
