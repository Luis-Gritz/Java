package br.com.opet.ex01;

public class Veiculo {
	int ano;

}
