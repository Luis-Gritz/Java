package br.com.opet.ex01;

public class Pessoa {
	
	//Atributos
	private int idade;
	private String profissao;
	
	//Metodos
	boolean SolicitarParada(Carro c) {
		boolean atendida = c.desacelera();
		
		if(atendida == true) {
			return true;
		}else {
			return false;
		}
	}
	
	private boolean validaIdade() {
		if(idade < 0 || idade>150) {
			System.out.println("Idade Inv�lida"+idade);
			return false;
		}
		
	}

	/**
	 * @return the idade
	 */
	public int getIdade() {
		
		return idade;
	}

	/**
	 * @param idade the idade to set
	 */
	public void setIdade(int idade) {
		if(validaIdade() == False) {
			
		}
		
		this.idade = idade;
	}

	/**
	 * @return the profissao
	 */
	public String getProfissao() {
		return profissao;
	}

	/**
	 * @param profissao the profissao to set
	 */
	public void setProfissao(String profissao) {
		this.profissao = profissao;
	}
}
