package br.com.opet.ex01;

public class Carro extends Veiculo {
	//Atributos
	String modelo;

	
	//Metodos
	boolean desacelera() {
		
		return false;
	}
}
