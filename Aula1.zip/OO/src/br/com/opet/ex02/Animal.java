package br.com.opet.ex02;

public class Animal {

}
